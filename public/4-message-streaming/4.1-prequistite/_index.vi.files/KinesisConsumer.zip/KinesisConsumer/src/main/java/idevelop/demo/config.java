package idevelop.demo;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.InitialPositionInStream;

public class config {

    public static final String ELASTICSEARCH_ENDPOINT = "REPLACE_WITH_YOUR_ELASTIC_SEARCH_ENDPOINT";
    public static final String REGION = "ap-southeast-2";
    
    // Initial position in the stream when the application starts up for the first time.
    // Position can be one of LATEST (most recent data) or TRIM_HORIZON (oldest available data)
    public static final InitialPositionInStream INITIAL_POSITION_IN_STREAM = InitialPositionInStream.LATEST;

    public static final long BACKOFF_TIME_IN_MILLIS = 3000L;
    public static final int NUM_RETRIES = 10;
    public static final long CHECKPOINT_INTERVAL_MILLIS = 60000L;

    // To run the sample on EC2, use the DefaultAWSCredentialsProviderChain 
    public static final AWSCredentialsProvider CREDENTIALS_PROVIDER = new DefaultAWSCredentialsProviderChain();
    
    // To run the sample on your local workstation, use the ProfileCredentialsProvider 
    //public static final AWSCredentialsProvider CREDENTIALS_PROVIDER = new ProfileCredentialsProvider("aws-lab-env");
    
    public static final String KINESIS_STREAM_NAME = "iDevelopElasticSearchKinesisStream";
    public static final String KINESIS_APPLICATION_NAME = "kinesisToElasticsearch";
}
