package idevelop.demo;
/*
 * Copyright 2012-2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

import java.io.ByteArrayInputStream;
import java.net.URI;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.AmazonWebServiceResponse;
import com.amazonaws.ClientConfiguration;
import com.amazonaws.DefaultRequest;
import com.amazonaws.Request;
import com.amazonaws.auth.AWS4Signer;
import com.amazonaws.http.AmazonHttpClient;
import com.amazonaws.http.AmazonHttpClient.RequestExecutionBuilder;
import com.amazonaws.http.ExecutionContext;
import com.amazonaws.http.HttpMethodName;
import com.amazonaws.http.HttpResponseHandler;
import com.amazonaws.services.kinesis.clientlibrary.exceptions.InvalidStateException;
import com.amazonaws.services.kinesis.clientlibrary.exceptions.ShutdownException;
import com.amazonaws.services.kinesis.clientlibrary.exceptions.ThrottlingException;
import com.amazonaws.services.kinesis.clientlibrary.interfaces.IRecordProcessor;
import com.amazonaws.services.kinesis.clientlibrary.interfaces.IRecordProcessorCheckpointer;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.ShutdownReason;
import com.amazonaws.services.kinesis.model.Record;

/**
 * Processes records and checkpoints progress.
 */
public class RecordProcessor implements IRecordProcessor {

	private static final String ELASTIC_SEARCH_SERVICENAME = "es";
    private static final Log LOG = LogFactory.getLog(RecordProcessor.class);
    private String kinesisShardId;
    private long nextCheckpointTimeInMillis;
    private final String indexDocument = "{" + 
		  "\"index\" :" + 
		  "{" + 
		    "\"_index\" : \"transactions\"," +
		    "\"_type\" : \"transaction\"" +
		  "}" +
		"}";

    private final CharsetDecoder decoder = Charset.forName("UTF-8").newDecoder();

    @Override
    public void initialize(String shardId) {
        LOG.info("Initializing record processor for shard: " + shardId);
        this.kinesisShardId = shardId;
    }

    @Override
    public void processRecords(List<Record> records, IRecordProcessorCheckpointer checkpointer) {
        LOG.info("Processing " + records.size() + " records from " + kinesisShardId);

        // Process records and perform all exception handling.
        processRecordsWithRetries(records);

        // Checkpoint once every checkpoint interval.
        if (System.currentTimeMillis() > nextCheckpointTimeInMillis) {
            checkpoint(checkpointer);
            nextCheckpointTimeInMillis = System.currentTimeMillis() + config.CHECKPOINT_INTERVAL_MILLIS;
        }
    }

    /**
     * Process records performing retries as needed. Skip "poison pill" records.
     * 
     * @param records Data records to be processed.
     */
    private void processRecordsWithRetries(List<Record> records) {
    	
    		String data = null;

	    AWS4Signer signer = new AWS4Signer();
	    signer.setRegionName(config.REGION);
	    signer.setServiceName(ELASTIC_SEARCH_SERVICENAME);

	    	StringBuilder sb = new StringBuilder();
        for (Record record : records) {
        	
        		try {
        			
	            // For this app, we interpret the payload as UTF-8 chars.
	            data = decoder.decode(record.getData()).toString();
        		
	            sb.append(indexDocument +"\n");
        			sb.append(data +"\n");
        	
        		}
        		catch(Exception ex)
        		{
        			System.out.println("EXCEPTION::" + ex.getMessage());
        		}
        }
        
        try
        {        
            boolean processedSuccessfully = false;
            for (int i = 0; i < config.NUM_RETRIES; i++) {
                    
                    Request<?> request = new DefaultRequest<Void>(ELASTIC_SEARCH_SERVICENAME);
                    request.setContent(
                    		new ByteArrayInputStream(
                    				sb.toString().getBytes())
                    		);
                    
                    request.setEndpoint(URI.create("https://" + config.ELASTICSEARCH_ENDPOINT + "/_bulk"));
                    request.setHttpMethod(HttpMethodName.POST);

                    signer.sign(request, config.CREDENTIALS_PROVIDER.getCredentials());
                    
                    AmazonHttpClient client = new AmazonHttpClient(new ClientConfiguration());
                    ExecutionContext executionContext = new ExecutionContext(true);
                    HttpResponseHandler<AmazonClientException> errorHandler = new ResponseHandler(new AmazonWebServiceResponse<Void>());
                    HttpResponseHandler<String> responseHandler = new ResponseHandler(new AmazonServiceException("Error"));
                    RequestExecutionBuilder requestExecutionBuilder = client.requestExecutionBuilder();
                    requestExecutionBuilder = requestExecutionBuilder.executionContext(executionContext);
                    requestExecutionBuilder = requestExecutionBuilder.request(request);
                    requestExecutionBuilder = requestExecutionBuilder.errorResponseHandler(errorHandler);
                    requestExecutionBuilder.execute(responseHandler);

                    processedSuccessfully = true;
                    break;
            }
        } 
        catch (Throwable t) 
        {
            LOG.warn("Caught throwable while processing record " + t.toString());
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void shutdown(IRecordProcessorCheckpointer checkpointer, ShutdownReason reason) {
        LOG.info("Shutting down record processor for shard: " + kinesisShardId);
        // Important to checkpoint after reaching end of shard, so we can start processing data from child shards.
        if (reason == ShutdownReason.TERMINATE) {
            checkpoint(checkpointer);
        }
    }

    /** Checkpoint with retries.
     * @param checkpointer
     */
    private void checkpoint(IRecordProcessorCheckpointer checkpointer) {
        LOG.info("Checkpointing shard " + kinesisShardId);
        for (int i = 0; i < config.NUM_RETRIES; i++) {
            try {
                checkpointer.checkpoint();
                break;
            } catch (ShutdownException se) {
                // Ignore checkpoint if the processor instance has been shutdown (fail over).
                LOG.info("Caught shutdown exception, skipping checkpoint.", se);
                break;
            } catch (ThrottlingException e) {
                // Backoff and re-attempt checkpoint upon transient failures
                if (i >= (config.NUM_RETRIES - 1)) {
                    LOG.error("Checkpoint failed after " + (i + 1) + "attempts.", e);
                    break;
                } else {
                    LOG.info("Transient issue when checkpointing - attempt " + (i + 1) + " of "
                            + config.NUM_RETRIES, e);
                }
            } catch (InvalidStateException e) {
                // This indicates an issue with the DynamoDB table (check for table, provisioned IOPS).
                LOG.error("Cannot save checkpoint to the DynamoDB table used by the Amazon Kinesis Client Library.", e);
                break;
            }
            try {
                Thread.sleep(config.BACKOFF_TIME_IN_MILLIS);
            } catch (InterruptedException e) {
                LOG.debug("Interrupted sleep", e);
            }
        }
    }
}
