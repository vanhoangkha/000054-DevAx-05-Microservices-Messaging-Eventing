package idevelop.demo;

import com.amazonaws.http.HttpResponse;
import com.amazonaws.http.HttpResponseHandler;
import com.amazonaws.util.IOUtils;

public class ResponseHandler<T> implements HttpResponseHandler<T> {
    private final T preCannedResponse;
    
    public ResponseHandler(T preCannedResponse) {     	
    		this.preCannedResponse = preCannedResponse; 
    	}

    @Override
    public T handle(HttpResponse response) throws Exception {
        System.out.println(IOUtils.toString(response.getContent()).substring(0, 200) + "...");
        return preCannedResponse;
    }

    @Override
    public boolean needsConnectionLeftOpen() { return false; }
}
