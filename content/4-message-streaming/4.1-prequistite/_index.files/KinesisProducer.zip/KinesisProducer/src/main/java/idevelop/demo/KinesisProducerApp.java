package idevelop.demo;
/*
 * Copyright 2012-2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

import java.io.File;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;

import com.amazonaws.AmazonClientException;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.kinesis.AmazonKinesis;
import com.amazonaws.services.kinesis.AmazonKinesisClientBuilder;
import com.amazonaws.services.kinesis.model.DescribeStreamRequest;
import com.amazonaws.services.kinesis.model.PutRecordsRequest;
import com.amazonaws.services.kinesis.model.PutRecordsRequestEntry;
import com.amazonaws.services.kinesis.model.PutRecordsResult;
import com.amazonaws.services.kinesis.model.ResourceNotFoundException;
import com.amazonaws.services.kinesis.model.StreamDescription;
import com.fasterxml.jackson.databind.ObjectMapper;

public class KinesisProducerApp {

	public static final String SAMPLE_APPLICATION_STREAM_NAME = "iDevelopElasticSearchKinesisStream";
	public static final String DATA_SOURCE_FILENAME = "./SalesData.csv";
    public static final int MAX_PRODUCTS_IN_SINGLE_TRANSACTION = 50;
    public static final int MAX_PRODUCT_COST = 500;
    public static final int MAX_MINUTES_BETWEEN_TRANSACTIONS = 15;
    
    private static AmazonKinesis kinesis;
    private static ObjectMapper mapper = new ObjectMapper();
    
    private static void init() throws Exception {

    		System.out.println("Obtaining credentials...");
    		AWSCredentialsProvider credentials = null;
        try {
        		 // Use DefaultAWSCredentialsProviderChain when running on EC2
             credentials = new DefaultAWSCredentialsProviderChain();
             // Use ProfileCredentialsProvider when running on development workstation
        		 //credentials = new ProfileCredentialsProvider("aws-lab-env");
            System.out.println("     done.");
        } catch (Exception e) {
            throw new AmazonClientException(
                    "Unable to load credentials",
                    e);
        }

        System.out.println("Building Kinesis Client...");
        kinesis = AmazonKinesisClientBuilder
	    		.standard()
	    		.withRegion(Regions.AP_SOUTHEAST_2)
	    		.withCredentials(credentials)
	    		.build();
        System.out.println("     done.");
    }

    public static void main(String[] args) throws Exception {
        
		System.out.println("****************************************");
		System.out.println("****************************************");
		System.out.println("**");
		System.out.println("** iDevelop<AWS> Kinesis record producer");
		System.out.println("**");
		System.out.println("****************************************");
		System.out.println("****************************************\n");

		init();

        final String myStreamName = KinesisProducerApp.SAMPLE_APPLICATION_STREAM_NAME;
        
        System.out.println("Using Stream Name '" + myStreamName +"'");

        // Describe the stream and check if it exists.
        DescribeStreamRequest describeStreamRequest = new DescribeStreamRequest().withStreamName(myStreamName);
        try {
        	
        		System.out.println("Describing stream...");
        	
            StreamDescription streamDescription = kinesis.describeStream(describeStreamRequest).getStreamDescription();
            System.out.printf("Stream %s has a status of %s.\n", myStreamName, streamDescription.getStreamStatus());

            if (!"ACTIVE".equals(streamDescription.getStreamStatus())) {
                System.out.println("Stream is not currently in a usable state.");
                System.exit(0);
            }
        } catch (ResourceNotFoundException ex) {
            System.out.println("ERROR::Stream could not be found. Exiting!");
            System.exit(0);
        }

        //
        // Setup our starting point for transactions - the start of 2017
        //
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
        Calendar simulatedTimeline = Calendar.getInstance();
        simulatedTimeline.set(2015, Calendar.JANUARY, 1, 0, 0, 0);
        
        //
        // Setup our Kinesis publisher 
        //
        PutRecordsRequest putRecordsRequest = new PutRecordsRequest();
        putRecordsRequest.setStreamName(myStreamName);
        ArrayList<PutRecordsRequestEntry> putRecordsEntries = new ArrayList<PutRecordsRequestEntry>();

        while(true)
        {
        		System.out.println("===========================================================");
        		System.out.println("           Starting from beginning of input file ");
        		System.out.println("           at simulated date/time " + sdf.format(simulatedTimeline.getTime()));
        		System.out.println("===========================================================");
        		
	        try {
	        
	        		Scanner scanner = new Scanner(new File(KinesisProducerApp.DATA_SOURCE_FILENAME));
	            scanner.useDelimiter("[,\\n\\r]+");
	
	            while (scanner.hasNext()) {
	            
	            		int recordsToSkip 				= (int)(Math.random() * 100) + 1;
	            		int recordsSkipped				= recordsToSkip;
	            		int recordsInThisBatch			= (int)(Math.random() * 500) + 1;
	            		int recordsInBatchLeftToWrite 	= recordsInThisBatch;
	        			putRecordsEntries.clear();
	        			
		            // Keep running through the source data until we have reached the end of records
		        		while(scanner.hasNext() && recordsInBatchLeftToWrite > 0){
		        
		            		// Make a new transaction at this simulated time 
		            		SaleItemTransaction transaction = new SaleItemTransaction();
		            		transaction.setRetailerType(scanner.next());
		            		transaction.setProductLine(scanner.next());
		            		transaction.setProductType(scanner.next());
		            		transaction.setProduct(scanner.next());
		            		
		            		if (--recordsSkipped == 0)
		            		{		    
			            		// Advance the simulated timeline
			            		simulatedTimeline.add(
			            				Calendar.MINUTE, 
			            				(int)(Math.random() * Math.ceil(KinesisProducerApp.MAX_MINUTES_BETWEEN_TRANSACTIONS))
			            				);

			            		transaction.setQuantity( (int) Math.ceil(Math.random() * KinesisProducerApp.MAX_PRODUCTS_IN_SINGLE_TRANSACTION) );
			            		transaction.setUnitCost(GetDoubleAsTwoDecimalPlaces(Math.random() * KinesisProducerApp.MAX_PRODUCT_COST));
			            		transaction.calculateTotalCost();
			            		transaction.setTimestamp(simulatedTimeline.getTime());
		            		
		            			String transactionAsJSON = mapper.writeValueAsString(transaction);
			        			PutRecordsRequestEntry entry = new PutRecordsRequestEntry()
			        					.withData(ByteBuffer.wrap(transactionAsJSON.getBytes()))
			        					.withPartitionKey(String.format("partitionKey-%d", System.currentTimeMillis()));
			        			
			        			putRecordsEntries.add(entry);
			        			
			        			recordsInBatchLeftToWrite--;
			        			
			        			recordsToSkip = (int)(Math.random() * 100) + 1;
			        			recordsSkipped = recordsToSkip;
		            		}
		        		}
		        			
		        		if ( putRecordsEntries.size() > 0 )
		        		{
						// Publish this block of events to the Kinesis stream
			        		putRecordsRequest.setRecords(putRecordsEntries);
			        		PutRecordsResult putRecordsResult = kinesis.putRecords(putRecordsRequest);
			        		
			        		System.out.println("Published " + recordsInThisBatch + " records to stream source.");
		        		}
	            }
	            scanner.close();
	        }
	        finally {
	
			}
        }

    }
    
    private static double GetDoubleAsTwoDecimalPlaces(double input)
    {
    		int multiplied = (int)(input * 10000.0f);
    		return multiplied / 10000;
    }
}
