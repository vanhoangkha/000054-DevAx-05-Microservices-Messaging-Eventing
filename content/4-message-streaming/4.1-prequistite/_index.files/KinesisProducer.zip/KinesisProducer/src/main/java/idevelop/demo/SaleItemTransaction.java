package idevelop.demo;

import java.util.Date;

public class SaleItemTransaction {
	
	private String productLine;
	private String retailerType;
	private String productType;
	private String product;
	private int quantity;
	private double unitCost;
	private double totalCost;
	private Date timestamp;

	public String getProductLine() {
		return productLine;
	}
	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}
	public String getRetailerType() {
		return retailerType;
	}
	public void setRetailerType(String retailerType) {
		this.retailerType = retailerType;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getUnitCost() {
		return unitCost;
	}
	public void setUnitCost(double unitCost) {
		this.unitCost = unitCost;
	}
	public double getTotalCost() {
		return totalCost;
	}
	public void calculateTotalCost() {
		totalCost = unitCost * quantity;
	}
	public Date getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}
}
